<template lang="pug">
.curso-main-container.pb-3
  BannerInterno(:subTitulo="'2.	Ley 1620 del 2013'")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.overflow-hidden
    .row.mb-5            
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-3.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/23.svg")
            .col-lg
              p.mb-0 ¿Alguna vez ha reflexionado sobre el impacto que tiene la convivencia escolar en el desarrollo integral de niñas y niños? La Ley 1620 del 2013 no se limita a regular comportamientos dentro de la escuela. Es una herramienta normativa que garantiza ambientes seguros, incluyentes y respetuosos de los derechos humanos, y por ello resulta clave para docentes en formación, especialmente en el nivel de educación infantil.      
        p(data-aos="fade-down") Este nivel educativo no solo está vinculado a contenidos académicos, sino también a la construcción de vínculos, la expresión de emociones y el aprendizaje de habilidades sociales. En ese sentido, la Ley 1620 sirve como guía para prevenir la violencia, educar para la sexualidad y fomentar una ciudadanía activa (Rodríguez, Hadad y Rodríguez, 2013).

      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/24.png", data-aos="zoom-in")  

    .bg-full-width.bg-color-11.mb-5
      .px-4.px-md-5
        .row.align-items-center
          .col-lg-auto
            img.img-a.img-t(src="@/assets/curso/temas/18.png")         
          .col-lg
            .py-4.j1
              p(data-aos="fade-down") Este recorrido invita a:
              ul.lista-ul--color            
                li.d-flex
                  i.far.fa-arrow-alt-circle-right.color-1
                  p.mb-0 Identificar los #[b elementos claves] de la Ley.
                li.d-flex
                  i.far.fa-arrow-alt-circle-right.color-1
                  p.mb-0 Reflexionar sobre su #[b aplicación práctica].
                li.d-flex
                  i.far.fa-arrow-alt-circle-right.color-1
                  p.mb-0 Reconocer su #[b valor formativo] como base para diseñar, implementar y mejorar el Manual de Convivencia.

    #t_2_1.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.1] Objetivos y alcance

    .row.mb-5
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-6.p-4.mb-4(data-aos="fade-up") 
          p(data-aos="fade-down").mb-0 #[b ¿De qué manera se construyen entornos escolares que realmente favorecen la formación integral y el bienestar de niñas, niños y adolescentes?] La Ley 1620, también conocida como Ley de Convivencia Escolar, responde a esta pregunta con una propuesta estructurada: la creación del Sistema Nacional de Convivencia Escolar. Este sistema articula acciones pedagógicas, institucionales e intersectoriales que aseguran el desarrollo armónico de los estudiantes, promoviendo la educación en derechos humanos, la prevención de la violencia y la formación ciudadana.
        p(data-aos="fade-down") A continuación, se presentan sus objetivos fundamentales y el alcance institucional:
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/25.png", data-aos="zoom-in")    

    .row.align-items-start.mb-5
      .col-lg-4.mb-3.mb-lg-0
        figure
          img.img-a.img-t(src="@/assets/curso/temas/26.png", alt="")     
      .col-lg-8 
        AcordionA(tipo="b")
          .div(titulo="Objetivos principales")
            ul.lista-ul--color            
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Promover la convivencia escolar como base del aprendizaje y la ciudadanía.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Establecer rutas de atención integral frente a vulneraciones.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Fomentar una cultura de paz basada en el respeto, la inclusión y el diálogo.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Involucrar a la familia y a la comunidad educativa en la formación ética y afectiva del estudiantado.  
          .div(titulo="Ámbito de aplicación")
            p Instituciones educativas oficiales y privadas de los niveles de preescolar, básica y media en todo el país. 
          .div(titulo="Instrumentos institucionales obligatorios")
            ul.lista-ul--color            
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 #[b Comité Escolar de Convivencia.] Prevención, seguimiento y atención de conflictos.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 #[b Sistema de Información Unificado (SIUCE).] Registro y análisis de casos.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 #[b Manual de Convivencia actualizado.] Con enfoque preventivo, restaurativo y formativo.

    .row.mb-5            
      .col-lg-8.mb-3.mb-lg-0 
        p(data-aos="fade-down") Esta Ley reconoce que la calidad educativa no depende exclusivamente del currículo, sino del entorno emocional, ético y relacional en el que se desarrolla el aprendizaje. En la educación infantil, esto cobra especial relevancia, dado que es en esta etapa donde se consolidan los primeros vínculos afectivos, sociales y normativos (Acosta y Castillo, 2017).

        .bg-color-3.p-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/27.svg")
            .col-lg
              p.mb-0 Por ello, cada institución debe revisar y ajustar sus planes institucionales, incluyendo el Manual de Convivencia, para alinearlos con los principios de la ley. El objetivo no es solo cumplir con una exigencia normativa, sino garantizar una educación digna, segura y participativa desde los primeros años.   

      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/28.png", data-aos="zoom-in")  

    p(data-aos="fade-down") Comprender la Ley 1620 y aplicarla desde la práctica docente implica mucho más que conocer su articulado. Significa traducir sus principios en acciones diarias que fortalezcan la empatía, la autonomía, el diálogo y la participación de niñas y niños como sujetos de derechos. De este modo, se construyen escuelas que cuidan, enseñan y transforman desde el respeto y la dignidad humana.

    #t_2_2.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.2] Principios para la convivencia y formación en derechos humanos

    .row.mb-5.align-items-center
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/29.png", data-aos="zoom-in")        
      .col-lg-8
        .bg-color-7.p-4.j1(data-aos="fade-left")
          h5(data-aos="fade-down") ¿Es posible construir una comunidad educativa armónica sin una base clara de principios que orienten la convivencia y el respeto por la dignidad humana? 

          p(data-aos="fade-down").mb-0 Esta pregunta permite reconocer que la formación en derechos humanos y la promoción de la convivencia escolar son pilares esenciales en el proceso educativo, especialmente en la Educación infantil. En el marco de la Ley 1620 del 2013, estos aspectos no son complementarios, sino ejes rectores que deben guiar las decisiones pedagógicas y la cultura institucional (Herrera, 2018).
        .bg-color-10.p-4.j1.mb-4(data-aos="fade-left")
          p(data-aos="fade-down").mb-0 La Ley establece una serie de principios orientadores que deben regir la vida escolar y convertirse en acciones concretas para transformar los entornos educativos en espacios de respeto, inclusión y participación. 
        p(data-aos="fade-down") A continuación, se presenta un resumen de estos principios y su aplicación práctica:          

    .bg-full-width.bg-fondo-slider.mb-0(data-aos="fade-right")
      .p-4.p-md-5
        SlyderA(tipo="b").bg-white
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Enfoque de derechos humanos
              p Reconoce a niñas, niños y adolescentes como #[b sujetos de derechos]. Garantiza la igualdad, la integridad y la participación, creando entornos seguros que promuevan el desarrollo integral, sin distinciones.   
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/30.png")   
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Formación para la ciudadanía y la paz
              p Impulsa el desarrollo de #[b habilidades sociales y emocionales], desde la infancia, a través del diálogo, el juego y la resolución pacífica de conflictos. Fomenta relaciones basadas en el respeto y la empatía.  
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/31.png")  
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Participación democrática
              p Promueve la #[b voz activa de la infancia] en la vida escolar. Invita a generar espacios de escucha, toma de decisiones y corresponsabilidad, fortaleciendo la autonomía y el sentido de pertenencia.  
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/32.png")  
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Inclusión y no discriminación
              p Rechaza toda forma de exclusión por género, cultura, religión, discapacidad, orientación sexual o condición socioeconómica. Garantiza #[b igualdad de oportunidades] para aprender y convivir.  
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/33.png")  
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Corresponsabilidad
              p Establece que la #[b protección y formación del estudiantado] es un compromiso colectivo. Implica la articulación entre docentes, familias, directivos, estudiantes y el Estado para prevenir y atender situaciones de riesgo.  
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/34.png")  
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Prevención y protección
              p Plantea un enfoque #[b proactivo] que permita anticiparse a conflictos o violencias. Propone estrategias pedagógicas orientadas al autocuidado, la gestión emocional y la promoción de ambientes seguros.  
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/35.png")  
    .bg-full-width.bg-color-2.p-4(data-aos="fade-left")
      .row.px-4
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/36.svg")
        .col-lg.j1
          p.mb-0 Estos principios no son conceptos abstractos; constituyen una hoja de ruta ética y pedagógica para quienes se preparan como docentes. No basta con conocer la Ley: se debe interpretar sus alcances y traducirlos en prácticas transformadoras dentro del aula.

    #t_2_3.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.3] Educación para la sexualidad y prevención de la violencia escola

    p(data-aos="fade-down") ¿De qué manera puede la escuela contribuir a formar personas autónomas, respetuosas y conscientes de su cuerpo, sus emociones y sus derechos? Este interrogante permite abordar dos ejes  esenciales de la Ley 1620 del 2013:


    .row.mb-5 
      .col-lg-6.mb-3 
        .bg-color-2.h-100.p-4(data-aos="fade-left")
          .row.align-items-center
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/37.svg")
            .col-lg
              p.mb-0 La educación para la sexualidad.

      .col-lg-6.mb-3 
        .bg-color-2.h-100.p-4(data-aos="fade-left")
          .row.align-items-center
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/38.svg")
            .col-lg
              p.mb-0 La prevención de la violencia escolar.

    p(data-aos="fade-down") Ambos componentes son fundamentales para garantizar entornos escolares seguros, inclusivos y basados en el respeto por los derechos humanos. Particularmente en la educación infantil, estos pilares no solo forman parte del currículo, sino que se viven en la cotidianidad del aula, donde cada gesto, palabra o experiencia pedagógica deja huella.

    h3(data-aos="fade-down") Enfoque integral de la educación para la sexualidad
    .bg-color-5.mb-5(data-aos="fade-up")
      .row.justify-content-center.align-items-center            
        .col-lg.order-lg-2
          .p-4
            p.mb-0(data-aos="fade-up") Con frecuencia, se reduce la educación sexual a lo biológico o reproductivo. Sin embargo, la Ley 1620 promueve una visión más amplia: la sexualidad como una dimensión humana integral, que abarca lo físico, lo afectivo, lo emocional, lo social y lo ético. Desde los primeros años, se deben construir las bases para reconocer el cuerpo como un espacio digno, establecer límites, convivir en la diversidad y ejercer la ciudadanía desde el respeto mutuo.
        .col-lg-auto.mb-3.mb-lg-0.order-lg-1
          figure
            img.img-a.img-t(src='@/assets/curso/temas/39.png', alt='') 



    h3(data-aos="fade-down") Prevención de la violencia escolar 
    p(data-aos="fade-down") La Ley también hace un fuerte énfasis en prevenir y atender todas las formas de violencia escolar: acoso, exclusión, violencia sexual, maltrato físico o psicológico y discriminación por género, identidad, orientación sexual, etnia o discapacidad. Esta prevención se operacionaliza mediante el Sistema Nacional de Convivencia Escolar, que articula acciones pedagógicas, institucionales y comunitarias.

    p(data-aos="fade-down") A continuación, se presenta ambos pilares y sus aplicaciones en el entorno escolar:


    .row.align-items-start.mb-5
      .col-lg-8.mb-3.mb-lg-0 
        AcordionA(tipo="b")
          .div(titulo="Educación para la sexualidad")
            ul.lista-ul--color            
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Reconocimiento y cuidado del cuerpo propio.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Establecimiento de límites personales.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Identificación de relaciones sanas.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Prevención del abuso y la discriminación.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Construcción de una imagen positiva de sí mismo y de los demás.   
          .div(titulo="Prevención de la violencia escolar")
            ul.lista-ul--color            
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Fortalecimiento de capacidades institucionales para la detección y atención.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Implementación de protocolos de atención integral.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Fomento de una cultura del cuidado y respeto.
              li.d-flex
                i.far.fa-arrow-alt-circle-right.color-1
                p.mb-0 Participación activa de toda la comunidad educativa en la creación de entornos protectores.                                                               
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/40.png", alt="") 

    h3(data-aos="fade-down") Rol del docente en educación infantil
    p(data-aos="fade-down") La aplicación de estos principios en el nivel infantil, exige del docente una actuación sensible, ética y pedagógicamente fundamentada. Las niñas y los niños deben poder: 

    .bg-full-width-3.bg-fondo-1
      .px-4.px-md-5.pb-md-3  
        .row.justify-content-center.mb-5 
          .col-lg-4
            figure
              img.img-a.img-t(src='@/assets/curso/temas/41.png', alt='')             
          .col-lg-8
            SlyderF.text-center(columnas="col-12 col-lg-6")
              .custom-image-card-2.h-100.sha.br-1
                img.custom-image-card__image(src="@/assets/curso/temas/42.png" alt="")
                .custom-image-card__text.p-2
                  p.mb-0 Nombrar lo que sienten sin temor. 
              .custom-image-card-2.h-100.sha.br-1
                img.custom-image-card__image(src="@/assets/curso/temas/43.png" alt="")
                .custom-image-card__text.p-2
                  p.mb-0 Reconocer cuándo una situación no es segura. 
              .custom-image-card-2.h-100.sha.br-1
                img.custom-image-card__image(src="@/assets/curso/temas/44.png" alt="")
                .custom-image-card__text.p-2
                  p.mb-0 Expresar afecto de forma respetuosa.
              .custom-image-card-2.h-100.sha.br-1
                img.custom-image-card__image(src="@/assets/curso/temas/45.png" alt="")
                .custom-image-card__text.p-2
                  p.mb-0 Preguntar sin ser censurados. 
              .custom-image-card-2.h-100.sha.br-1
                img.custom-image-card__image(src="@/assets/curso/temas/46.png" alt="")
                .custom-image-card__text.p-2
                  p.mb-0 Recibir orientación sin ser juzgados.

    .bg-full-width.bg-color-2.p-4.mb-5(data-aos="fade-left")
      .row.px-4
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/47.svg")
        .col-lg.j1
          p.mb-0 Esto implica una formación docente sólida, con enfoque en derechos, equidad de género y desarrollo socioemocional. Cada situación en el aula, desde un conflicto por un juguete hasta una conversación espontánea sobre el cuerpo o las emociones, es una oportunidad para educar en el respeto, la dignidad y la empatía.

    h3(data-aos="fade-down") Reflexión final
    p(data-aos="fade-down") Educar para la sexualidad y prevenir la violencia, no es una tarea impuesta por manuales o normativas. Se construye en las relaciones cotidianas, en el vínculo afectivo con el estudiantado y en el compromiso con su bienestar.

    .row.mb-5
      .col-lg-7.mb-3.mb-lg-0 
        .bg-color-1.p-4.h-100(data-aos="fade-up") 
          p(data-aos="fade-down") La Ley 1620 del 2013 proporciona el marco legal, pero su verdadero impacto se materializa en el ejercicio docente diario. ¿Qué acciones concretas permiten construir entornos escolares donde niñas y niños se sientan escuchados, seguros y valorados?

          p(data-aos="fade-down").mb-0 Esta es una pregunta que debe acompañar cada experiencia educativa y orientar cada decisión pedagógica.    
      .col-lg-5
        figure
          img.img-a.img-t(src="@/assets/curso/temas/48.png", data-aos="zoom-in")           

    .bg-full-width.bg-color-10.mb-5
      .px-4.p-md-5
        .row.justify-content-center.align-items-center
          .col-lg-4.mb-3.mb-lg-0
            figure(data-aos="zoom-in")
              img(src='@/assets/curso/temas/49.png', alt='')                              

          .col-lg-8
            h2.mb-4(data-aos="flip-up") Implicaciones para el manual de convivencia
            p.mb-4(data-aos="fade-right") Se invita a leer el documento Implicaciones para el manual de convivencia, donde se aborda cómo el Manual de Convivencia escolar puede convertirse en una herramienta transformadora para la construcción de ambientes educativos seguros, inclusivos y respetuosos.
            a.anexo.mb-4.bg-white.w-fit(:href="obtenerLink('/downloads/Anexo_1.pdf')" target="_blank")(data-aos="flip-up")
              .anexo__icono(:style="{'background-color': '#FCDFDB'}")
                img(src="@/assets/template/icono-pdf.svg")
              .anexo__texto
                p <strong>Anexo. </strong> Implicaciones para el manual de convivencia



    .bg-full-width.border-top.color-primario
      .p-4.p-md-5
        h2(data-aos="fade-left") MATERIAL COMPLEMENTARIO
        .row.material-complementario
          .col-12.col-md-6.col-lg-7
            p Los invitamos a explorar el material complementario de este curso, en esta sección encontrará recursos que le permitirán profundizar  y enriquecer su aprendizaje en los temas tratados en esta unidad.

            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://elibro.net/es/lc/tecnologicadeloriente/titulos/4945" target="_blank" rel="noopener noreferrer") Folgueira Hernández, M. & Subías Pérez, J. M. (2018). Educación infantil. Ministerio de Educación y Formación Profesional de España. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://elibro.net/es/lc/tecnologicadeloriente/titulos/14581" target="_blank" rel="noopener noreferrer") Castellanos Delgado, J. L. (2003). Psicología, prevención e infancia en riesgo social. Colegio Oficial de la Psicología de Madrid. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://www.ciencialatina.org/index.php/cienciala/article/view/6055" target="_blank" rel="noopener noreferrer") Gómez Urrego, J. F. (2023). La Convivencia escolar a la luz de la ley 1620, perspectivas y posibilidades. Ciencia Latina Revista Científica Multidisciplinar, 7(2), 9588-9607. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://repository.unad.edu.co/handle/10596/34916" target="_blank" rel="noopener noreferrer") Saballeth Miranda, M. J. (2020). Aplicación de la Ley de convivencia escolar 1620 del 2013 en Colombia. periodo 2016–2019.                                           

            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://blog.kawak.net/mejorando_sistemas_de_gestion_iso/ley-sobre-acoso-escolar" target="_blank" rel="noopener noreferrer") Vargas Pardo, S. (2022). Conoce a detalle la Ley 1620 de 2013 sobre acoso escolar. Blog KAWAK. 
            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://www.fundacionconvivencia.org/post/convivencia-escolar-más-que-una-ley" target="_blank" rel="noopener noreferrer") González Reyes, M. (2022). Convivencia escolar más que una Ley. Fundación Convivencia.  

            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=o8MjiJcobHY" target="_blank" rel="noopener noreferrer") NO AL MATONEO ESCOLAR O BULLYING. (2014). PRIMER ENCUENTRO DE SECRETARIOS DE EDUCACION LEY 1620 DE CONVIVENCIA ESCOLAR MATONEO [video]. 
            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=_QLSs8dViVk" target="_blank" rel="noopener noreferrer") Ministerio de Educación Nacional. (2022). Intervención del Ministro de Educación sobre el Sistema Nacional de Convivencia Escolar [video].               

          .col-12.col-md-6.col-lg-3.offset-lg-1
            figure
              img(src='@/assets/componentes/material-complementario.svg', alt='')

</template>

<script>
export default {
  name: 'Tema2',
  data: () => ({}),

  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
}
</script>

<style lang="sass"></style>
