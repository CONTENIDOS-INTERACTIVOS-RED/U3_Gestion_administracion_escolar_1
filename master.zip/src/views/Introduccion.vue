<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5 
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in")     
      .col-lg-8
        p(data-aos="fade-down") La convivencia escolar es un componente esencial del desarrollo educativo y humano. En las instituciones educativas, no solo se transmiten conocimientos, sino también valores, normas y formas de relacionarse que configuran el ambiente escolar. Por ello, garantizar espacios armónicos, participativos y respetuosos es clave para una formación integral.
        .bg-color-7.p-4(data-aos="fade-up") 
          p(data-aos="fade-down").mb-0 En este contexto, el Gobierno Escolar y el Manual de Convivencia, surgen como herramientas fundamentales para organizar la vida institucional y promover la participación democrática. Su existencia está respaldada por un marco legal que busca asegurar el respeto por los derechos humanos y prevenir cualquier forma de violencia.

    .bg-full-width.bg-color-2.p-4(data-aos="fade-left")
      .row.px-4
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/2.svg")
        .col-lg.j1
          p.mb-0 Esta unidad aborda los fundamentos normativos que orientan estos instrumentos, haciendo énfasis en la Ley 1620 del 2013 y el Decreto 1095 del mismo año. A través de su análisis, se pretende fortalecer el rol del docente como mediador de la convivencia y como guía en la formación ciudadana desde los primeros años escolares.      
</template>
