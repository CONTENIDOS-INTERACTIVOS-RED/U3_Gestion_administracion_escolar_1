module.exports = 'Gobierno Escolar y Reglamento o Manual de Convivencia'
